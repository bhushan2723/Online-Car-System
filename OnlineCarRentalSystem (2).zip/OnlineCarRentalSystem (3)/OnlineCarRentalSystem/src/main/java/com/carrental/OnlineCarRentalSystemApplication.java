package com.carrental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineCarRentalSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineCarRentalSystemApplication.class, args);
	}

}
