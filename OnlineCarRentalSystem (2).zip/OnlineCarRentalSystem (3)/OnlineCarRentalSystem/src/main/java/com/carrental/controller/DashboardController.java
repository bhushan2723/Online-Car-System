package com.carrental.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import jakarta.servlet.http.HttpSession;

@Controller
public class DashboardController {

    @GetMapping("/customer/dashboard")
    public String customerDashboard(HttpSession session, Model model) {
        if (session.getAttribute("role") == null || !session.getAttribute("role").toString().equals("CUSTOMER")) {
            return "redirect:/login";
        }
        model.addAttribute("username", session.getAttribute("userId"));
        return "customer-dashboard";
    }

    @GetMapping("/admin/dashboard")
    public String adminDashboard(HttpSession session, Model model) {
        if (session.getAttribute("role") == null || !session.getAttribute("role").toString().equals("ADMIN")) {
            return "redirect:/login";
        }
        model.addAttribute("username", session.getAttribute("userId"));
        return "admin-dashboard";
    }

    @GetMapping("/superadmin/dashboard")
    public String superAdminDashboard(HttpSession session, Model model) {
        if (session.getAttribute("role") == null || !session.getAttribute("role").toString().equals("SUPERADMIN")) {
            return "redirect:/login";
        }
        model.addAttribute("username", session.getAttribute("userId"));
        return "superadmin-dashboard";
    }
}
