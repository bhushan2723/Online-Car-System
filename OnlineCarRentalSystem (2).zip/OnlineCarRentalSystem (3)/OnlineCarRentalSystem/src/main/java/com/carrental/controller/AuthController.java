package com.carrental.controller;

import com.carrental.entities.User;
import com.carrental.entities.Role;
import com.carrental.entities.Status;
import com.carrental.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    // Show login page
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    // Show register page
    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    // Register user (Customer or Admin)
    @PostMapping("/register")
    public String register(@RequestParam String name,
            @RequestParam String email,
            @RequestParam String phone,
            @RequestParam String password,
            @RequestParam String role,
            RedirectAttributes redirectAttrs) {
        try {
            User user = new User();
            user.setName(name);
            user.setEmail(email);
            user.setPhone(phone);
            user.setPassword(password); // raw password
            user.setStatus(Status.ACTIVE);

            // Convert string role to enum
            Role userRole;
            if (role.equalsIgnoreCase("ADMIN")) {
                userRole = Role.ADMIN;
            } else if (role.equalsIgnoreCase("CUSTOMER")) {
                userRole = Role.CUSTOMER;
            } else {
                redirectAttrs.addFlashAttribute("error", "Invalid role selected");
                return "redirect:/register";
            }

            userService.registerUser(user, userRole); // UserService me method update hona chahiye

            redirectAttrs.addFlashAttribute("success", "Registered successfully as " + userRole);
            return "redirect:/login";
        } catch (Exception e) {
            redirectAttrs.addFlashAttribute("error", "Email already registered");
            return "redirect:/register";
        }
    }

    // Login user with role check
    @PostMapping("/login")
    public String login(@RequestParam String email,
            @RequestParam String password,
            @RequestParam String role,
            HttpSession session,
            RedirectAttributes redirectAttrs) {
        try {
            User user = userService.login(email, password);

            // Role validation
            if (!user.getRole().toString().equalsIgnoreCase(role)) {
                redirectAttrs.addFlashAttribute("error", "Selected role does not match user role");
                return "redirect:/login";
            }

            session.setAttribute("userId", user.getUserId());
            session.setAttribute("role", user.getRole());

            // Redirect to dashboard based on role
            switch (user.getRole()) {
                case CUSTOMER:
                    return "redirect:/customer/dashboard";
                case ADMIN:
                    return "redirect:/admin/dashboard";
                case SUPERADMIN:
                    return "redirect:/superadmin/dashboard";
            }

        } catch (RuntimeException e) {
            redirectAttrs.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/login";
    }

    // Logout
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
