package com.carrental.entities;

public enum Status {
    ACTIVE, INACTIVE, PENDING
}