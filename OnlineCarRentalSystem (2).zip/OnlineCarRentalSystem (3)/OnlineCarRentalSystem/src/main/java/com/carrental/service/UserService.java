package com.carrental.service;

import com.carrental.entities.User;
import com.carrental.entities.Role;
import com.carrental.entities.Status;
import com.carrental.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    // Customer or Admin Registration (dynamic role)
    public User registerUser(User user, Role role) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole(role);
        user.setStatus(Status.ACTIVE);
        return userRepository.save(user);
    }

    // Login
    public User login(String email, String password) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new RuntimeException("Bad credentials");
        }

        if (user.getStatus() != Status.ACTIVE) {
            throw new RuntimeException("Account not active");
        }

        return user;
    }

    // Create Admin or SuperAdmin (with constant password)
    public User createAdmin(String name, String email, String phone, Role role, String password) {
        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPhone(phone);
        user.setRole(role);
        user.setStatus(Status.ACTIVE);
        user.setPassword(passwordEncoder.encode(password)); // constant password
        return userRepository.save(user);
    }

    // public User createSuperAdmin() {
    // String email = "superadmin@car.com";
    // String password = "super@123"; // constant password
    // if (userRepository.findByEmail(email).isPresent()) {
    // return userRepository.findByEmail(email).get(); // already exists
    // }
    // User user = new User();
    // user.setName("Super Admin");
    // user.setEmail(email);
    // user.setPhone("0000000000");
    // user.setRole(Role.SUPERADMIN);
    // user.setStatus(Status.ACTIVE);
    // user.setPassword(passwordEncoder.encode(password));
    // return userRepository.save(user);
    // }

}
