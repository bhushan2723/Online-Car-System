package com.carrental.entities;

public enum Role {
    CUSTOMER, ADMIN, SUPERADMIN
}
